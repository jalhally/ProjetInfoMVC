package tlob.view;

import java.awt.event.*;

public class SoloActionListener implements ActionListener {


public SoloActionListener(){
	
}
@Override
public void actionPerformed(ActionEvent arg0) {
	}
}