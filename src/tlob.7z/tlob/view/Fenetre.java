package tlob.view;

import javax.swing.JFrame;
import tlob.model.*;

public class Fenetre extends JFrame /*controller implements KeyListener*/{
	
	private static final long serialVersionUID = 1L;

	private Panel panel;
	
	public Fenetre(Level level, LoadIAD loadIAD) {
	    setVisible(true) ;
		setSize(15*41, 15*42+5+90);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		panel = new Panel(level, loadIAD);
		getContentPane().add(panel);
		
		//controller
		
		/*
		addKeyListener(this);
		
		Timer timer = new Timer(30, new ActionListener() {
			
			
			@Override
			public void actionPerformed(ActionEvent e) {
				wololo();
				
			}
		});
		timer.start();
		
	}
	
	public ArrayList<ArrayList<int[]>> listAllAroundPixel(List<Decor> list) {
		ArrayList<ArrayList<int[]>> listAllAroundPixel = new ArrayList<ArrayList<int[]>>();
		for(Decor decor : list) {
			if (decor.getClass()== Floor.class){
				
			}
			else{
			listAllAroundPixel.add(decor.listAroundPixel());
		}
		}
		return listAllAroundPixel;
			
	}

	private List<Link> rajouteLink(List<Link> liste,int x,int y){
		
	  Link link = new Link(3,x,y,2,1,linkRun,5,3,0,true,true,0);
	  liste.add(link);
	  return liste;
	  
	}
	
	private List<Decor> rajouteDecor(List<Decor> liste,int x,int y, Image image){
		
		  liste.add(new Decor(x,y,image));
		  return liste;
		  
		}
	

	
	private void wololo() {

		if(liste.get(0).getInvincible() == 0){
			//System.out.println("hihihihi Link est invincible...");
			liste.get(0).tickInvicible();
		}
		if(monster.size() > 0){
			for(int i = 0; i < monster.size(); i++){
				if(monster.get(i).getInvincible() == 0){
					//System.out.println("Le monstre n°" + i + " est invincible...");
					monster.get(i).tickInvicible();
				}
				if(monster.get(i).getLifePoint() == 0){
					monster.remove(i);
					//System.out.println("Le monstre n°" + i +" est mort!");
				}
			}
		}
		
		liste.get(0).linkInteraction(d, monster, b,bonus,map);
		
		if(droiteEnfoncee){
			liste.get(0).setIAD(linkRun);
	    	liste.get(0).moveRight();
			
		}
		if(gaucheEnfoncee){
			liste.get(0).setIAD(linkRun);
	    	liste.get(0).moveLeft();
		}
		
		if(basEnfoncee){
			liste.get(0).setIAD(linkRun);
	    	liste.get(0).moveDown();
		}
		
		if(hautEnfoncee){
			liste.get(0).setIAD(linkRun);
	    	liste.get(0).moveUp();
		}
		
		if(tireFleche){
			liste.get(0).setIAD(linkArrow);
			liste.get(0).fireArrow(ar,arrow);
			if(liste.get(0).getActualFrame() == 6){
				tireFleche = false;
				liste.get(0).setActualFrame(1);
			}
		}
		if(ar.size()>0){
			for(int p = 0; p < ar.size(); p++){
				int a = ar.get(p).projectileInteraction(liste, monster,d,b);
				if(a != 0){
					if(a == 2){
						ar.get(p).tick();
						ar.get(p).setActualFrame(1);
						if(ar.get(p).getTime() == 15){
							ar.remove(p);
						}
					}
					else{
						ar.remove(p);
					}
				}
			}
		}
		if(setBomb){
			if(b.size()< liste.get(0).getNumberBomb()){
				liste.get(0).setBomb(b, bomb);				
			}
			setBomb = false;
		}
		if(b.size()>0){
			for(int p = 0; p < b.size(); p++){
				b.get(p).bombInteraction(d,liste,monster,b);
				b.get(p).tick();
				if(b.get(p).getTime() == 15){ //changer dans deflagration si changement de temps
					bombDeflagration.add(new BombDeflagration(b.get(p).getXPos(),b.get(p).getYPos(),deflagration,2,2));
					b.remove(p);
				}
			}
		}
		if(bombDeflagration.size()>0){
			for(int p = 0; p < bombDeflagration.size(); p++){
				bombDeflagration.get(p).tick();
				if(bombDeflagration.get(p).getPortee() < liste.get(0).getRangeBomb()*4+2){
					bombDeflagration.get(p).appear(liste.get(0).getRangeBomb(),d,bonus);
					bombDeflagration.get(p).defInteraction(liste, monster, b);
				}
				else{
					bombDeflagration.remove(p);
				}
			}
		}
		if(feu.size()>0){
			for(int p = 0; p < feu.size(); p++){
				feu.get(p).tick();
				feu.get(p).move();
					if(feu.get(p).getList().size() < feu.get(p).getPos()-1){
						feu.remove(p);
					}
			}
		}
				if(useStaff==true && liste.get(0).getStaff()!=-1) {
			if(liste.get(0).getStaff()==0) {
			for (Monster m : monster) {
				m.setLifePoint(m.getLifePoint()-1);
				System.out.println("monstre hihihi a"+" "+m.getLifePoint());				
			}
			useStaff=false; liste.get(0).setStaff(-1); System.out.println("firestaff off");
		}
			else if(liste.get(0).getStaff()==1) {
				for (Monster m : monster) {
					m.setFrozen();
					m.tickFrozen();	
					if(m.getFrozen()==1) {
						useStaff=false; liste.get(0).setStaff(-1); System.out.println("icestaff off");
					
				}
				
			}
		}
		}
		repaint();
	}

	@Override
	public void keyPressed(KeyEvent e) {
	    int keyCode = e.getKeyCode();
	    if (keyCode == KeyEvent.VK_RIGHT)
	    	droiteEnfoncee = true;
    	else if(keyCode == KeyEvent.VK_LEFT) {
    		gaucheEnfoncee = true;
    	}
    	else if(keyCode == KeyEvent.VK_DOWN) {
    		basEnfoncee = true;
    	}
    	else if(keyCode == KeyEvent.VK_UP) {
    		hautEnfoncee = true;
    	}
    	else if(keyCode == KeyEvent.VK_X){
    		tireFleche = true;
    	}
    	else if(keyCode == KeyEvent.VK_SPACE){
    		setBomb = true;
    	}
    	    	else if(keyCode == KeyEvent.VK_C) {
    		useStaff = true;
    	}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		int i = 0;
		liste.get(0).setActualFrame(1);
	    int keyCode = e.getKeyCode();
	    if (keyCode == KeyEvent.VK_RIGHT){
	    	droiteEnfoncee = false;
	    	//link.posZ.set(0, 174);
	    }
    	else if(keyCode == KeyEvent.VK_LEFT){
    		gaucheEnfoncee = false;
	    	//link.posZ.set(0, -4);
    	}
    	else if(keyCode == KeyEvent.VK_DOWN) {
    		basEnfoncee = false;
	    	//link.posZ.set(0, -4);
    	}
    	else if(keyCode == KeyEvent.VK_UP) {
    		hautEnfoncee = false;
	    	//link.posZ.set(0, -4);
    	}
    	

	}

	@Override
	public void keyTyped(KeyEvent e) {
		//System.out.println("Code touche tapÃ©e : " + e.getKeyCode() + " - caractÃ¨re touche tapÃ©e : " + e.getKeyChar());

	      
		// TODO Auto-generated method stub
		*/
	}
}
