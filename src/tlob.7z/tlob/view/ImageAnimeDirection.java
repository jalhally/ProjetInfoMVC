package tlob.view;

import java.awt.Image;
import java.awt.Toolkit;
import java.util.List;
import java.util.ArrayList;

import tlob.model.*;
import tlob.model.Character;

public class ImageAnimeDirection {
	private List<Image> liste;
	public final static int GAUCHE = 0;
	public final static int DROITE = 1;
	public final static int HAUT = 2;
	public final static int BAS = 3;
	private int myTick = 0;
	private int actualFrame = 1;
	private int constant;
	String nomBase;
	private int frames;
	private Image image;
	
	public ImageAnimeDirection(String name){
		this.nomBase = name;
		this.image = Toolkit.getDefaultToolkit().getImage(nomBase);
	}
	
	public ImageAnimeDirection(String nomBase, int frames, int constant) {
		this.frames = frames;
		this.nomBase = nomBase;
		this.constant = constant;
		liste = new ArrayList<Image>();
		
		for(String dir : new String[]{"Left", "Right", "Up", "Down"}){
			for(int i = 1; i<= frames; i++){
				liste.add(Toolkit.getDefaultToolkit().getImage(nomBase + dir + Integer.toString(i) + ".png"));
			}
		}
	}
	
	public void tick() {
		this.myTick++;
		if(this.myTick == constant) {
			this.actualFrame++;
			this.myTick = 0;
			if(this.actualFrame == 6)
				this.actualFrame = 1;
		}
	}
	
	public int getActualFrame(){
		return this.actualFrame;
	}

	public void setActualFrame(int a)
	{
		this.actualFrame=a;
	}
	
	public String getName(){
		return this.nomBase;
	}
	
	public int getFrames(){
		return this.frames;
	}
	
	public Image getImage(){
		return this.image;
	}
	
	public Image getImageAnime(Character character){
		if(character.getDirection() == GAUCHE){
			return liste.get(actualFrame -1);
		}
		else if(character.getDirection() == DROITE){
			return liste.get(actualFrame + frames-1);
		}
		else if(character.getDirection() == HAUT){
			return liste.get(actualFrame + 2*frames-1);
		}
		else{
			return liste.get(actualFrame + 3*frames-1);
		}
	}
	
	public Image getImage(FireBall1 f){
		return liste.get(0);
	}
	
	public Image getImageAnime(Arrow a){
		if(a.getDirection() == GAUCHE){
			return liste.get(actualFrame -1);
		}
		else if(a.getDirection() == DROITE){
			return liste.get(actualFrame  + frames-1);
		}
		else if(a.getDirection() == HAUT){
			return liste.get(actualFrame  + 2*frames-1);
		}
		else{
			return liste.get(actualFrame  + 3*frames-1);
		}
	}
	
	public List<Image> getImageDirection(int direction){
		ArrayList<Image> l = new ArrayList<Image>();
		if(direction == GAUCHE){
			for(int i=0; i< frames;i++){
				l.add(liste.get(i));
			}
		}
		else if(direction == DROITE){
			for(int i=0; i< frames;i++){
				l.add(liste.get(i + frames));
			}
		}
		else if(direction == HAUT){
			for(int i=0; i< frames;i++){
				l.add(liste.get(i + 2*frames));
			}
		}
		else{
			for(int i=0; i< frames;i++){
				l.add(liste.get(i + 3*frames));
			}
		}
		return l;
	}
	
}
	