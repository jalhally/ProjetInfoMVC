package tlob.view;

import java.util.ArrayList;
import java.util.List;

public class LoadIAD {
	
	private List<ImageAnimeDirection> dataIAD;
	
	public LoadIAD(){ //ne pas oublier de load
		List<ImageAnimeDirection> dataIAD = new ArrayList<ImageAnimeDirection>();
		dataIAD.add(new ImageAnimeDirection("res/2.png"));
		dataIAD.add(new ImageAnimeDirection("res/LinkRun",6,5));
		dataIAD.add(new ImageAnimeDirection("res/LinkArrow",6,5));
		dataIAD.add(new ImageAnimeDirection("res/Arrow",3,5));
		dataIAD.add(new ImageAnimeDirection("res/Deflagration",2,2));
		dataIAD.add(new ImageAnimeDirection("res/MeleeRun",1,5));
		dataIAD.add(new ImageAnimeDirection("res/BackgroundForest.png"));
		dataIAD.add(new ImageAnimeDirection("res/LittleTree.png"));
		dataIAD.add(new ImageAnimeDirection("res/Jar.png"));
		dataIAD.add(new ImageAnimeDirection("res/Rocks.png"));
		dataIAD.add(new ImageAnimeDirection("res/Rock.png"));
		dataIAD.add(new ImageAnimeDirection("res/Root.png"));
		//dataIAD.add(new ImageAnimeDirection(""));
	}
	
	public ImageAnimeDirection stringToIAD(String name){
		for(int i = 0; i < dataIAD.size(); i++){
			if(dataIAD.get(i).getName() == name){
				return dataIAD.get(i);
			}
		}
		return dataIAD.get(0);
		//load Kirby si ne trouve pas le nom
	}
	
}
