package tlob.model;

public class FireBall2 {

	public FireBall2(int xPos, int yPos) {
		// TODO Auto-generated constructor stub
	}

}
