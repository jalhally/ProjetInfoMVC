package tlob.model;

public class Melee extends Monster {
	
	public Melee(int lifePoint, int xPos, int yPos, int speed,int direction, String name)
	{
		super(lifePoint, xPos, yPos,speed, direction, name);
	}


}
