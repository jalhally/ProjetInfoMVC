package tlob.model;

public class Thunder extends Item {

	public Thunder(int xPos, int yPos, String name) {
		super(xPos, yPos, name);
	}

}
