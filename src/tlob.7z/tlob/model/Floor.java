package tlob.model;

public class Floor extends Decor{

	public Floor(int xPos, int yPos, String name) {

		super(xPos,yPos,name);

	}

}