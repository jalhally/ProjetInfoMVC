package tlob.model;

public class Hole extends Trap {
	
	public Hole(int xPos, int yPos, String name) {
		super(xPos,yPos,name);
	}

}
