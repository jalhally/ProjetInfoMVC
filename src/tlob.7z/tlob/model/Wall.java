package tlob.model;

public class Wall extends Decor {
	
	public Wall(int xPos, int yPos, String name) {
		super(xPos,yPos,name);
	}

}
