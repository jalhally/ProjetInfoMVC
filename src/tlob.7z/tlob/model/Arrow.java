package tlob.model;

public class Arrow extends Item{
	
	private int direction;
	private int x;
	private int y;
	
	public Arrow(int xPos, int yPos,String name, int direction){
		super(xPos,yPos,name);
		this.x = xPos;
		this.y = yPos;
		this.direction = direction;
	}
	
	/*
	private int t = 0;
	private int myTick;
	
	public void tick(){
		this.myTick++;
		if(this.myTick == 5) {
			this.t++;
			this.myTick = 0;
		}
	}
	
	public int getTime(){
		return this.t;
	}
	*/
	
	public int getX(){
		return this.x;
	}
	
	public int getY(){
		return this.y;
	}
	
	public int getDirection()
	{ 
		return direction;
	}
	
	public void setDirection (int direction)
	{
		this.direction = direction;
	}
	
	public void move(){
		if(direction == 0){
			setXPos(getXPos() - 10);
			
			//view
			//tick(getIAD(),getC());
		}
		if(direction == 1){
			setXPos(getXPos() + 10);
			
			//view
			//tick(getIAD(),getC());
		}
		if(direction == 2){
			setYPos(getYPos() - 10); //panel 
			
			//view
			//tick(getIAD(),getC());
		}
		if(direction == 3){
			setYPos(getYPos() + 10); //panel
			
			//view
			//tick(getIAD(),getC());
		}
	}
	
}
