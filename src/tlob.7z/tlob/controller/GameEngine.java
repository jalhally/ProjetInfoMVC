package tlob.controller;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import tlob.model.*;
import tlob.view.*;

public class GameEngine implements KeyListener {
	
	private Level level;
	private GameController controller;
	
	public GameEngine(Map map, Fenetre fenetre){
		level = new Level(map);
		controller = new GameController(level);
		fenetre.addKeyListener(this);
	}

	@Override
	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	public void update(){
		controller.update();
	}
}
